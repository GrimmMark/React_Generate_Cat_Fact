import './App.css';
import Axios from "axios";
import { useEffect, useState } from 'react';

function App() {

  const [catFact, setCatFact] = useState("")
 


    const fetchCatFact = () => {
      Axios.get("https://catfact.ninja/fact").then((res) => {
      setCatFact(res.data.fact)
    });
  };
  useEffect(() =>{
    fetchCatFact();
  }, []);

    return (
      <div className="App">

        <div className="Header">
          <h1>ᓚᘏᗢ</h1>
        </div>


<div className='container'>
<div className="center">
        <button className='btn' onClick={fetchCatFact}>
        <svg width="180px" height="60px" viewBox="0 0 180 60" className="border">
          <polyline points="179,1 179,59 1,59 1,1 179,1" className="bg-line" />
          <polyline points="179,1 179,59 1,59 1,1 179,1" className="hl-line" />
        </svg>
        <span>Generate Cat Fact</span>
        </button>
        </div>
        </div>
        <p> {catFact} </p>

      </div>

    );

  }

export default App;
